--CREATE DATABASE tspdb;
--USE tspdb;
--CREATE USER 'tspdbuser'@'localhost' IDENTIFIED BY 'tspdbpass';
--GRANT ALL PRIVILEGES ON * . * TO 'tspdbuser'@'localhost';
--FLUSH PRIVILEGES;
USE tspdb;
CREATE TABLE job_table(
   	job_id INT NOT NULL AUTO_INCREMENT,
	jobname LONGBLOB,
	workdir LONGBLOB,
	command LONGBLOB,
	parameter LONGBLOB,
	output_file LONGBLOB,
	error_file LONGBLOB,
	log_file LONGBLOB,
	email_address_to LONGBLOB,
	email_address_cc LONGBLOB,
	email_address_bcc LONGBLOB,
	send_email_start LONGBLOB,
	send_email_end LONGBLOB,
	send_email_fail LONGBLOB,
	restart CHAR(2),
	max_restart INT
);


